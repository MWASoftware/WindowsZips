Set Term ^;
Create Procedure CallEvent(
  EventName VarChar(32)
)
As
Begin
  Post_Event :EventName;
End^
set term ;^
  
