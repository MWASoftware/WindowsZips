Create Table LotsOfData ( 
    RowID integer not null, 
    theDate TimeStamp, 
    MyText VarChar(1024), 
    Primary Key (RowID) 
  );                 
