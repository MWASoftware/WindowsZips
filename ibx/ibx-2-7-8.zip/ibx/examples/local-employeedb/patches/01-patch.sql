Create Table DBVERSIONINFO(
  VersionNo Integer not null
);

Insert into DBVERSIONINFO(VersionNo) Values(1);
Commit;



