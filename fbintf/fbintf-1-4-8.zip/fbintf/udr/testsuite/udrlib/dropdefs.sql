drop function MyRowCount;
drop function BadRowCount;
drop function UDRInfo;
drop function GetCurDir;
drop procedure MyTestProc;
drop procedure MyErrorProc;
drop procedure MySelectProc;
drop procedure MyReadText;
Alter Table EMPLOYEE drop PREVIOUS_PHONE_EXT;
drop trigger MyEmployeeUpdate;
drop procedure ShowAttachments;
drop procedure GetServerInfo;
drop user TESTER;

