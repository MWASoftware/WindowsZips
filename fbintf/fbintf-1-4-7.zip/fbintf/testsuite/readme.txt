# The Firebird Pascal API Test Suite

MWA Software's Firebird Pascal API package (fbintf) comes with its own test suite. This is a console mode program that is designed to provide a comprehensive function and regression test for the package. It comprises eighteen individual tests, testing 115 features.

See the document TestSuite.pdf in the docs directory for more information.
