Select MyRowCount('EMPLOYEE') from RDB$Database;
Select MyRowCount('DEPARTMENT') from RDB$Database;
select MyRowCount('BAD') from RDB$Database;
Select UDRINFO() from RDB$Database;
Select GetCurDir() from RDB$Database;
