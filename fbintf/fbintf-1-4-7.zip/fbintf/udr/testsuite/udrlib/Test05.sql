Select * from ShowAttachments(NULL);
Select * from ShowAttachments('');
Select * from ShowAttachments('TESTER');
Select * from ShowAttachments('SYSDBA');
Select * from GetServerInfo;
