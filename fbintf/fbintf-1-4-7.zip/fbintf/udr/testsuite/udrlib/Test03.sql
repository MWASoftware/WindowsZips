Select * From MySelectProc;
Select Text From MyReadText('testtext.txt');
Select Text From MyReadText('test.empty');
