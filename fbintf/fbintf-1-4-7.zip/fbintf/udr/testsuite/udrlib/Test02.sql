Execute Procedure MYTESTPROC(24);
Execute Procedure MYERRORPROC(0);
Execute Procedure MYERRORPROC(1);
Execute Procedure MYERRORPROC(2);

