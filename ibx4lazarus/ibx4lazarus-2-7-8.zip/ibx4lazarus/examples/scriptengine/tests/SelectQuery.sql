Select * From EMPLOYEE;
Select * from DEPARTMENT;
