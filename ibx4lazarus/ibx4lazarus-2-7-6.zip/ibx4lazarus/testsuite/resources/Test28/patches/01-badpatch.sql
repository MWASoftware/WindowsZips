Create table GoodTable(
  TheKey integer not null,
  aText VarChar(12),
  Primary Key(TheKey)
);

Create table blah;

INSERT INTO DBVERSIONINFO (VERSIONNO) VALUES(2);

